Traffic Violation Data Analysis :
-----------------------------------

Input : Traffic_Violoations.csv
This file is attached with the project folder. Code directly refers it from the same location.
This data set that is downloaded from kaggle

There is one input text file that is needed to run the program which contains the list of states of united states.
This text file also is attached to the project folder.

Tech stack
---------------
Language : Python language 
Python modules : Numpy, Pandas, os, random
PyCharm as IDE for developing program

How to run the program :
-------------------------
1.Un zip the folder which contains the code and input files. Please keep the “main.py” as the start up page and run the program to get the results. 
2.import “pandas”, “Numpy”, install if not already installed.
3.The output was written into a text file in the same location where the code resides.